﻿using System.Collections;
using System.Collections.Generic;
using System.Timers;
using UnityEngine;

// Bochater
public class Character1 : Creature {

    private Bullet bullet;
    private GameObject game;

    private string horizontal = "Horizontal";
    private string vertical = "Vertical";

    private float fireExpectation = 0.5F;
    private float nextFire = 0.0F;

    private bool die = false;

    private States State
    {
        get { return (States)animator.GetInteger("State"); }
        set { animator.SetInteger("State", (int)value); }
    }

    // Ładowanie objektów
    protected override void Awake()
    {
        base.Awake();
        
        speed = 3f;
        lives = 3;

        bullet = Resources.Load<Bullet>("Bullet");
        game = GameObject.Find("GameController");
    }

    // Sterowanie bochaterem
    private void FixedUpdate() {

        if (die)
        {
            return;
        }

        State = States.sol_stand;
        
        if (Input.GetButton(horizontal))
        {
            RunHorizontal();
        }

        if (Input.GetButton(vertical))
        {
            RunVertical();
        }
        

        if (Input.GetButton("Fire1") && Time.time > nextFire)
        {
            nextFire = Time.time + fireExpectation;
            Shoot();
        }
	}

    // Sterowanie poziome
    private void RunHorizontal()
    {
        Vector3 directionVector = transform.right * Input.GetAxis(horizontal);
        spriteRenderer.flipX = directionVector.x < 0F;


        directionVector = Vector3.MoveTowards(
            transform.position,
                transform.position + directionVector,
            speed * Time.deltaTime);

        if (directionVector.x > -6f && directionVector.x < 6f)
        {
            transform.position = directionVector;
            State = States.sol_walk;
        }
    }

    // Sterowanie pionowe
    private void RunVertical()
    {
        Vector3 directionVector = transform.up * Input.GetAxis(vertical);

        directionVector.z = directionVector.y;

        directionVector = Vector3.MoveTowards(
            transform.position,
            directionVector + transform.position,
            speed * Time.deltaTime);

        if (directionVector.y > -4.5f && directionVector.y < 0.5f)
        {
            transform.position = directionVector;
            State = States.sol_walk;
        }
    }

    // Strzelanie
    private void Shoot()
    {

        Vector3 positionVector = transform.position;
        bool flipX = spriteRenderer.flipX;

        positionVector.x += flipX ? -0.5F : 0.5F;

        Bullet newBullet = Instantiate(bullet, positionVector, bullet.transform.rotation);

        newBullet.parent = gameObject;

        newBullet.directionVector = newBullet.transform.right * (flipX ? -1F : 1F); 
    }

    // Otrzymanie uszkodzeń
    public override void Damage()
    {
        lives--;
        
        if (lives == 0)
        {
            Die();
        }

    }
    
    // Smierć bochatera
    public override void Die()
    {
        game.SendMessage("Die");
        State = States.sol_die;
        die = true;
    }
    
    // Napotkanie na object
    private void OnTriggerEnter2D(Collider2D collider)
    {
        Creature creature = collider.gameObject.GetComponent<Creature>();
        Bullet bullet = collider.gameObject.GetComponent<Bullet>();

        if (creature)
        {
            Damage();
        }

        if (bullet && bullet.parent != gameObject)
        {
            Damage();
        }
        
    }
    
    // Stany aniemacji
    protected enum States
    {
        sol_stand,
        sol_walk,
        sol_die
    }
}

