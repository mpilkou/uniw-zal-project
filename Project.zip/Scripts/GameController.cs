﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Klasssa sterująca grę
public class GameController : MonoBehaviour
{
    public GameObject panel;
    public GameObject zombie;
    public int zombieCounter = 10;
    public float waitSpawn = 0.5f;
    public float waitWave = 10f;

    private int[] zLevel = new int[3];

    private int score { get; set; }

    private bool elive = true;
    public Text cText;

    // Inicja  
    void Start()
    {
        score = 0;
        Update();
        StartCoroutine(SpawnWaves());
    }

    // Sterowanie "Falą"
    IEnumerator SpawnWaves()
    {
        yield return new WaitForSeconds(1);

        while (elive)
        {
            int p = zombieCounter - 10;
            int Tscore = score + zombieCounter;

            for (int i = 0; i < 3; i++)
            {
                if (p % 3 == 0)
                {
                    zLevel[i] = p / 3;
                }
            }

            for (int i = 0; i < zombieCounter && elive; i++)
            {
                int r = Random.Range(1, -5);

                Vector3 spawnPosition = new Vector3(
                (Random.Range(0, 2) == 0 ? -7.5f : 7.5f),
                    r,
                        r);
                
                GameObject z = Instantiate(zombie, spawnPosition, Quaternion.identity);
                z.SendMessage("Lives", 2);
                
                yield return new WaitForSeconds(waitSpawn);
            }

            if (!elive)
            {
                break;
            }
            
            while(score != Tscore && elive)
            {
                yield return new WaitForSeconds(waitSpawn);
            }
            zombieCounter = (int)Mathf.Ceil(zombieCounter * 1.2f);
        }
        panel.SetActive(true);

    }

    // Zwiększenie rekordu
    public void Add(int add)
    {
        score += add;
        Update();
    }

    // Otrzymanie rekordu
    public int GetScore()
    {
        return score;
    }

    // Orświeżenie rekordu
    public void Update()
    {
        cText.text = "Score: " + score;
    }

    // Śmierć bochatera
    public void Die()
    {
        elive = false;
    }
}
