﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreController : MonoBehaviour {

    public GameObject table;
    private Text[] t = new Text[8];
    public string[] scores;

	// Pobieranie rekordów
	IEnumerator Start () {
        WWW data = new WWW("http://localhost/Project/SelectData.php");
        yield return data;
        scores = data.text.Split('\n');
        
        for (int i = 0; i < 8; i++)
        {
            t[i] = table.transform.FindChild(i.ToString()).GetComponentInChildren<Text>();
        }
        
        
        for (int i = 0; i < 8; i++)
        {
            try
            {
                t[i].text = "" + scores[i];
            }
            catch (System.IndexOutOfRangeException)
            {
                break;
            }
        }
    }



}
