﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class KeysInport : MonoBehaviour {

    public EventSystem eventSystem;
    public GameObject selected;

    private bool isSelect;
	
	// Sterowanie przeciskami
	void Update () {
        if (isSelect == false && Input.GetAxisRaw("Vertical") != 0)
        {
            eventSystem.SetSelectedGameObject(selected);
            isSelect = true;
        }
	}

    // wyłączenie
    private void OnDisable()
    {
        isSelect = false;
    }
}
