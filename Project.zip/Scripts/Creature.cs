﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Klassa istot
public class Creature : MonoBehaviour {

    protected int lives { set; get; }
    protected float speed;

    protected Animator animator;
    protected SpriteRenderer spriteRenderer;

    // Ładowanie objektów
    protected virtual void Awake()
    {
        spriteRenderer = GetComponentInChildren<SpriteRenderer>();
        animator = GetComponent<Animator>();
    }

    // Otrzymanie uszkodzeń
    public virtual void Damage()
    {
        Die();
    }

    // Śmierć
    public virtual void Die()
    {
        Destroy(gameObject);
    }
}
