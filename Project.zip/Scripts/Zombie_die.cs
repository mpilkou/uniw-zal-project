﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zombie_die : MonoBehaviour {

    private GameController gameController;

    // Inicjalizacja (śmierć porwora)
    void Start () {
        gameController = GameObject.Find("GameController").GetComponent<GameController>();
        
        if (gameController == null)
        {
            Debug.Log("Cannot find 'GameController' script");
        }

        gameController.Add(1);

        Destroy(this.gameObject, 0.65f);
	}
	
}
