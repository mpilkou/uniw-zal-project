<?php
	$server = "localhost";
	$user = "user";
	$db = "game";
	$connect = new mysqli($server, $user, NULL ,$db);
	
	if(!$connect){
		die("Failer connection".mysqli_connect_error());
	}
	
	$select = "SELECT Nick, Score, Date FROM scores ORDER BY Score DESC LIMIT 8;";
	$results = mysqli_query($connect, $select);
	
	if(mysqli_num_rows($results) != 0){
		while($result = mysqli_fetch_assoc($results)){
			echo "NICK: ".$result['Nick'].
				" SCORE: ".$result['Score'].
				" DATE: ".
				date("d-m-y g:i A", strtotime($result['Date']))."\n";		
		}
	}
?>