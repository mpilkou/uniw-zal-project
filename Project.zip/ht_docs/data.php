<?php

	function db_connect (){
		$server = "localhost";
		$user = "root";
		$db = "game";
		$connect = new mysqli($server, $user, NULL ,$db);
		if(!$connect){
			die("Failer connection".mysqli_connect_error());
		}
		
		return $connect;
	}
	

	
	function select(){
		$connect = db_connect();
		
		$select = "SELECT Nick, Score, Date FROM scores ORDER BY Score;";
		$results = mysqli_query($connect, $select);
		
		if(mysqli_num_rows($results) != 0){
			
			return $results;
			
		}
	}
	
?>