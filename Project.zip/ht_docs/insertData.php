<?php
	$server = "localhost";
	$user = "user";
	$db = "game";
	
	
	$nick = $_POST["postNick"];
	$score = $_POST["postScore"];
	
	$connect = new mysqli($server, $user, NULL ,$db);
	if(!$connect){
		die("Failer connection".mysqli_connect_error());
	}
	$insert = "INSERT INTO scores (Nick, Score)
				VALUES ('".$nick."','".$score."')";
				
	$result = mysqli_query($connect, $insert);
?>