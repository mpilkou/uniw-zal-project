<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Hight scores</title>
  <link rel="stylesheet" href="main.css">
</head>

<body>
  <div id="all">

	<div id="menu">
		<h1>Hight Scores</h1>
    </div>
    <div id="main">
      <table>
        <?php
        	include ('data.php');
        	$results = select();
        	foreach($results as $result):
        ?>

            <tr><h3 id = "score">
              Nick: <?php echo $result['Nick'] ?>
        			SCORE: <?php echo $result['Score'] ?>
        			Date: <?php echo date("d-m-y g:i A", strtotime($result['Date'])) ?>
            </h3></tr>


        <?php endforeach;?>
      </table>
    </div>

  </div>
</body>

</html>
